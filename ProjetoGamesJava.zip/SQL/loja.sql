﻿-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 11-Jun-2018 às 22:12
-- Versão do servidor: 10.1.32-MariaDB
-- PHP Version: 7.2.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `loja`
--
--
CREATE DATABASE IF NOT EXISTS `loja` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `loja`;

-- --------------------------------------------------------
-- --------------------------------------------------------

--
-- Estrutura da tabela `tbl_jogos`
--

CREATE TABLE `tbl_jogos` (
  `id_tbl_jogos` int(11) NOT NULL,
  `nome_tbl_jogo` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `genero_tbl_jogo` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `imagem_tbl_jogo` varchar(70) COLLATE utf8_unicode_ci NOT NULL,
  `valor_tbl_jogo` float(7,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Extraindo dados da tabela `tbl_jogos`
--

INSERT INTO `tbl_jogos` (`id_tbl_jogos`, `nome_tbl_jogo`, `genero_tbl_jogo`, `imagem_tbl_jogo`, `valor_tbl_jogo`) VALUES
(2, 'GTA I', 'Ação', 'FbzsEW4gAboNTUxWERodtBnDEtzlvEqtQKUv87clgCb2XfqIjcBs11vOqfR9n.jpg', 80.00),
(9, 'Call Of Duty WWII', 'Guerra', 'NVcEf8QBmKMxVVGainV0CKS35Uj.jpg', 144.90),
(10, 'Farcry 5', 'Tiro', '9ZbYMbDS7xqZiLM4HJYen0gV07MauLJgeXpFbu.jpg', 189.99),
(11, 'Fifa 18', 'Futebol', 'TqiLbADYOkpxiDPGZP2Ji.jpg', 98.50),
(12, 'God of War III', 'Guerra', 'e2WwRCYW9rdwSPvyIPuohTbLIRehU7xfU1NbcXaFfUk.jpg', 29.99),
(13, 'Gran Turismo Sport', 'Corrida', 'iDFUyfOgmuX6gIhYYYQZMC6P9T08kU7Eh6K07YY1X.jpg', 101.00),
(14, 'Mortal Kombat XL', 'Luta', 'DWOtzVohgITk886a4QFwQDFUn2Sic6II3TaNI3s8k4PR9GbXnjKaa7iVf.jpg', 79.90),
(15, 'Marvel vs Capcom Infinity', 'Luta', 'p061HyHUAAnL9NlgDhvYnKY8oitdZR9N5A4uaXuUDnqoQPexW4xyd.jpg', 69.00),
(16, 'Pes 2018', 'Futebol', 'zXEgjkQO5xNVvB9OX21u2dPWddufszNSYLIh.jpg', 79.00),
(17, 'The Last of US', 'Tiro', 'H1QNoLFRmYTw833epCpNyiuVkGYLo2xlgjEWw.png', 50.99),
(18, 'Uncharted 4', 'Tiro', 'W4IXIiEQo2b8b9wUYpnWMwT.jpg', 74.09);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_jogos`
--
ALTER TABLE `tbl_jogos`
  ADD PRIMARY KEY (`id_tbl_jogos`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_jogos`
--
ALTER TABLE `tbl_jogos`
  MODIFY `id_tbl_jogos` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;


 Estrutura da tabela `clientes`
--

CREATE TABLE `clientes` (
  `id_cliente` int(10) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `cpf` varchar(12) NOT NULL,
  `telefone` int(9) NOT NULL,
  `email` varchar(30) DEFAULT NULL,
  `endereco` varchar(100) NOT NULL,
  `bairro` varchar(20) DEFAULT NULL,
  `cidade` varchar(20) DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL,
  `cep` int(8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `fornecedores` (
  `nome` varchar(100) NOT NULL,
  `nome_resp` varchar(100) NOT NULL,
  `data_inclusao`date NOT NULL

) ENGINE=InnoDB DEFAULT CHARSET=latin1;
